<?php
 if(!($_SERVER['HTTP_HOST'] =='localhost')) {
	include ('mqttLog.php');
} ?>
<!DOCTYPE html>
<html lang="en">
<meta name=viewport content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<meta name="description" content="Artisan cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest,Farmstead,artisan, Washington,Oregon">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" >

<title>NW Cheese</title>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js" ></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js" ></script>

<script type="text/javascript">

$(document).ready(function(){
	
	
	});	//end ready function
</script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-273964-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>
<div class='container'>
	<div class="row">
		<div class='col-sm-6'>
			<img src='../images/cheese2.png' height='200px'/>
		</div>
		<div class='col-sm-6'>
			<br><h1>NW Cheesemakers</h1>
			<h4>Washington and Oregon Artisans</h4>
		</div>

	</div>
</div>
<br>

<div class='container bg-light'>
<!--navbar -->
<?php include 'navbarBS4.php'; ?>
</div>

<div class='container'><h2>Contact Us</h2><br></div>

<div class='container'>
<div class="row">
    <div class="col-sm-6">
<h3><a href='mailto:bsmith@primebiz.com?subject=nwcheese.com' >Click here to email the Editor</a></h3>
<p>Please email us with your comments,updates and corrections. </p><br>
<h3><b>US Mail:</b></h3>
<p>NWCheese.com<br>
%Primebiz.Net
<br>PMB #87<br>
3110 Judson Street<br>
Gig Harbor, WA 98335</p>
		</div>

<div class="col-sm-6">
<h3>Recipes</h3>
<p><a href='Beechers_Fondue_Recipe.pdf' target='_blank' style='color:#888888;'>Pacific Northwest Cheese Fondue</a></p>
<p><a href='http://www.thenibble.com/reviews/main/cheese/cheese2/macaroni-and-cheese-recipes5.asp' target='_blank' style='color:#888888;'>Pacific Northwest Mac & Cheese</a></p>
<h3>Links</h3>
<p><a href='https://oregoncheeseguild.org/' style='color:#888888;' target='_blank'>Oregon Cheese Guild</a></p>
<p><a href='http://www.washingtoncheese.org/' style='color:#888888;' target='_blank'>Washington State Cheesemakers Association</a></p>
<p><a href='https://www.cheesesociety.org/' style='color:#888888;'  target='_blank'>American Cheese Society</a></p>

</div>
	</div>
</div>


<?php include 'footer.php';  ?>
</body>
</html>
