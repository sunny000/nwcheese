<?php
 if(!($_SERVER['HTTP_HOST'] =='localhost')) {
	include ('mqttLog.php');
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>cheese Search</title>
	 <!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<meta name="description" content="Artisan cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest,Farmstead,artisan, Washington,Oregon">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" >
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js" ></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js" ></script>

	<style>
	</style>
</head>
<body>
<div class='container'>
	<div class="row">
		<div class='col-sm-6'>
			<img src='../images/cheese2.png' height='200px'/>
		</div>
		<div class='col-sm-6'>
			<br><h1>NW Cheesemakers</h1>
			<h4>Washington and Oregon Artisans</h4>
		</div>

	</div>
</div>
<br>

<div class='container bg-light'>
<!--navbar -->
<?php include 'navbarBS4.php'; ?>
</div>

<div class='container'>

<h1>Cheese Search</h1>
<p>Looking for a cheese-related subject? Try our special 'cheese search engine':</p>
<p>Just enter your search term in the search box below.</p>
<script async src="https://cse.google.com/cse.js?cx=011864631903894805788:manb3ywfbnm"></script>
<div class="gcse-search"></div>

</div>
<div class='container'>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-273964-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<br/><br/>
<?php include 'footer.php';  ?>
</div>
</body>	
</html>