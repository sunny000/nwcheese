<?php 
if(!$_SERVER['HTTP_HOST'] =='localhost') {
	include ('mqttLog.php');
}
?>


<!DOCTYPE html>
<html lang="en">
