<?php include ('mqttLog.php'); ?>

<!DOCTYPE html>
<html lang="en">
<html>
<head>
<script>
// Simulate an HTTP redirect:
window.location.replace("http://nwcheese.com/or1.php");
</script>

<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<meta name=viewport content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link  type="text/css" rel="stylesheet" href='cheese1.css'>
<meta name="description" content="Artisan cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,Oregon,Washington,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" >

<title>Oregon Artisan Cheesemakers</title>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js" ></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js" ></script>

<script type="text/javascript">
$(document).ready(function(){

	});	//end ready function
</script>


<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-273964-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>
<div id='page'>
<div id='banner'>
</div><!-- end of banner div -->

<!--navbar -->
<?php include 'navbar.php'; ?>

<div class='intro'><b>Artisan cheese makers of the Pacific Northwest</b><br>
Oregon artisan, farmstead, and
specialty cheese makers placed among the top national honors awarded during
the American Cheese Society's 2007 Annual Cheese Competition, winning a
total 22 awards. The honors represent the most awards ever won by Oregon
cheese makers in a single national competition, according to the Oregon
Cheese Guild and Oregon Dairy Products Commission.
</div>
<div id='col1'>
<div class='item'><a href='http://www.junipergrovefarm.com/'  target="_blank"  rel='noopener'>Juniper Grove Farm</a></div>
<div class='location'>Redmond, OR</div>

<p>There's no better place for producing top-quality goat milk cheese than the sunny, high desert of Central Oregon.
 The region is rich with volcanic soils and blessed with fresh air and clean water originating from the Cascade Mountain snowpack.</p>
<div class='item'><a href='http://www.wvcheeseco.com/'  target="_blank"  rel='noopener'> Willamette Valley Cheese Company</a></div>
<div class='location'>Salem, OR</div>

<p>Aged a minimum of four months, Willamette Valley Cheese Company's Gouda is complex and flavorful. 
Textures range from semi-hard to soft, encapsulated by a distinctively natural rind. It gains distinction as it ages.</p>
</div><!-- end of col 1 div -->

<div id='col2'>
<div class='item'><a href='http://www.oregongourmetcheeses.com/'  target="_blank"  rel='noopener'> Oregon Gourmet Cheeses</a></div>
<div class='location'>Albany, OR</div>
<p>At our small artisan cheesery in the Willamette Valley, we take great pride in hand crafting our cheeses.
 We use superb milk from a single Jersey herd, which is organically farmed and pasture fed at the Gourley Family Farm in Scio.</p>
 
 <div class='item'><a href='http://www.roguecreamery.com/'  target="_blank"  rel='noopener'> Rogue Creamery</a></div>
<div class='location'>Central Point, OR</div>
<p>An artisan cheese company, with people dedicated to sustainability and the art and tradition of making the world's finest handmade cheese.</p>
</div><!-- end of col2 div -->

<div id='col3'>
 <div class='item'><a href='http://www.tumalofarms.com/'  target="_blank"  rel='noopener'> Tumalo Farms</a></div>
<div class='location'>Bend, OR</div>
<p>Tucked in the triangle between Bend, Sisters, and Redmond, Tumalo Farms is 84 acres of lush land surrounded by beautiful views of the Cascades. At approximately 3,500 feet above sea level,
 the high desert climate offers crisp alpine air and more than 300 days of sunshine a year.</p>
 
 <div class='item'>Farmstead Cheese</div>
<div class='location'>Glossary Term</div>
Cheese made on the farm using only the milk from the
cheesemaker's own herd.
</div><!-- end of col 3 div -->

<div id='ads'>
<script type="text/javascript"><!--
google_ad_client = "pub-9028303977713070";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-08-10: nwcheese
google_ad_channel = "1949571433";
//-->
</script>

<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div><!-- end of ads div -->

<div id='footer'>
<p>&copy;Copyright 2010-2020 <a href='http://baywoodenterprises.com'  target="_blank"  rel='noopener'>Baywood Enterprises Inc</a></p>
</div><!-- end of footer div -->

  </div><!-- end of page div -->
<script type="text/javascript" src="navbar.js" ></script>

</body>
</html>
