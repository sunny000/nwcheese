<html lang="en">
<meta name=viewport content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<meta name="description" content="Artisan cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,Portland,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest,cheesemakers,bleu">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" />

<title>NW Cheese | Directory</title>
<style>
a {color:#444;text-decoration:none;}
.page {width:800px;margin:auto;border: 1px solid blue;padding:20px;}
.col1 {width:250px;float:left;}
.col2 {width:200px;float:left;}
.col3 {width:100px;float:left;}
.idcol {width:50px;float:left;}
.clear {clear:both;}
</style>
<script type="text/javascript" src="js/jquery-latest.min.js" ></script>
<script type="text/javascript" src="js/jquery-ui.min.js

<script type="text/javascript">

$(document).ready(function(){
	});	//end ready function
</script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-273964-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</head>
<body>
<div class='container'>
	<div class="row">
		<div class='col-sm-6'>
			<img src='images/cheese2.png' height='200px'/>
		</div>
		<div class='col-sm-6'>
			<br><h1>NW Cheesemakers</h1>
			<h4>Washington and Oregon Artisans</h4>
		</div>

	</div>
</div>
<br>
<!--navbar -->
<div class='container bg-light'>
<!--navbar -->
<?php include 'navbarBS4.php'; ?>
</div>

<div class="container">
