<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>RSS</title>
<style>
.column {width:400px;padding:5px;}
.descrip {padding:5px;}
</style>
</head>
<body>
<div class='column'>
<?php
$docRoot=$_SERVER['DOCUMENT_ROOT'];
$fpath=$docRoot.'/rss/rss_fetch.inc';
require_once($fpath);
	$url = "http://www.pnwcheese.com/feed"; //rss news source
	$rss = fetch_rss( $url );	
		
	foreach ($rss->items as $item) {
		$href = $item['link'];
		$title = $item['title'];
		$description=$item['description'];
		$summary=$item['summary'];
		
		//$published=substr($item['published'],0,10);
		
		echo "<p><a href='$href' target='_blank'><b>$title</b></a>";
		//echo "<br><i>$published</i></p>";
		echo "<p class='descrip'>$summary</p>";

	
	}
	echo "</ul>";
?>
</div>
</body>
</html>