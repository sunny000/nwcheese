<?php
 if(!($_SERVER['HTTP_HOST'] =='localhost')) {
	//include ('mqttLog.php');
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta name=viewport content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">

</head>
<body>
<div class='container'>
	<div class="row">
		<div class='col-sm-6'>
			<img src='../images/cheese2.png' height='200px'/>
		</div>
		<div class='col-sm-6'>
			<br><h1>NW Cheesemakers</h1>
			<h4>Washington and Oregon Artisans</h4>
		</div>

	</div>
</div>
<br>
<div class='container bg-light'>
	<?php include 'navbarBS4.php'; ?>
</div>

<div class='container'><p>From the Skagit Valley to downtown Seattle, Washington cheesemakers are demonstrating their commitment to all-natural artisan products, creating cheeses that are not just popular
 in the state of Washington but that have been recognized worldwide.</p>
</div ><hr>
<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <div class='item'><a href='http://www.beechershandmadecheese.com/' target='_blank'   rel='noopener' ><b>Beecher's Handmade Cheese</b></a></div>
		<div >Pike Place Market in Seattle, WA</div>
		<br><p>Beecher's signature cheese, <b>Flagship</b>, is a creamy combination of cheddar and gruyere, carefully aged for one year and delivering a distinctive, robust, nutty flavor. </p>
		<p>Flagship pairs nicely with a Pouilly Fuisse or a Syrah</p>
	</div>
    <div class="col-sm-4 ">
      <div class='item'><a href='http://www.mttownsendcreamery.com/'  target="_blank"    rel='noopener'><b>Mt Townsend Creamery</b></a></div>
	<div >Port Townsend, WA</div>

	<br><p>Mt Townsend Creamery's <b>Trailhead</b> falls somewhere between Comte and Cantal.
	It is a mild cheese with mellow flavor that depends on the quality of the milk and grazing land to provide its flavor. Trailhead is aged three to six months.</p>

    </div>
	
	    <div class="col-sm-4 ">
		
       <div class='item'><a href='http://rivervalleycheese.com/'  target="_blank"  rel='noopener'><b>River Valley Cheese</b></a></div>
		<div >Issaquah, WA</div>

		<br><p>A raw cow's milk aged monteray style cheese with a creamy, buttery taste and texture. 
		Naturally cream colored with no artificial ingredients or added colorants. <b>Valley Girl Cheese</b>, a real farmstead raw cow's milk cheese!
		 Mild in taste, usually aged for two to four months.</p>
    </div>

  </div>
</div>
<hr>
<div class="container">
  <div class="row">
    <div class="col-sm-4 ">
      <div class='item'><a href='http://samishbaycheese.com/'  target="_blank"  rel='noopener'><b>Samish Bay Cheese</b></a></div>
<div class='location'>Bow, WA</div>

<br><p><b>Gouda</b>, a traditional Dutch cheese, is mild and creamy when young. Our aged Gouda develops a nice sharp flavor, becoming drier and crumbly over time.
 We have flavored Goudas, including Herb (parsley, chives, garlic), Cumin, Nettle, and Caraway.</p>

    </div>
    <div class="col-sm-4 ">
      <div class='item'><a href='http://www.kurtwoodfarms.com/' target='_blank'><b>Kurtwood Farms</b></a></div>
<div class='location'>Vashon,WA</div>

<br><p><b>Dinah’s Cheese</b>&nbsp;<br>
A bloomy-rind cheese, it resembles a traditional French Camembert.</p><p> The fatty, Jersey milk gives it a deep golden color, and when fully ripe will be gooey and full flavored.  </p><br>
  
    </div>
	<div class="col-sm-4 ">
      <div class='item'><a href='http://cascadiacreamery.com/'  target="_blank"  rel='noopener'><b>Cascadia Creamery</b></a></div>
 <div class='location'>Trout Lake, WA</div>

<br><p><b>Sleeping Beauty</b>&nbsp;
A cheese with many layers and a unique rind that reflects the changes of the seasons. Smooth and buttery with a supple sharpness.</p>
 
    </div>
  </div>
</div>
<?php include 'footer.php' ; ?>
</body>
</html>