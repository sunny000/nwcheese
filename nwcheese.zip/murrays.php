<html>
<head>
<style>
<link rel="stylesheet" type="text/css" media="screen" href="http://localhost/css/reset.css" />
<link rel="stylesheet" type="text/css" media="screen" href="http://localhost/css/bfs.css" />

#col2 {width:400px;border : 1px solid red;float:left;}
#col3 {width:400px;border : 1px solid red;float:left;}
.descr {font-size:10pt;}
.title {font-size:12pt;}
.date {font-size:8pt;}
</style>
</head>
<body>
<?php
require_once 'rss2Function.php';

//Runs function with feed url and number of posts as arguments
//$my_rss = fetch_rss_feed('http://cappelendesign.no/blog/feed', 5); 
$my_rss = fetch_rss_feed('murrays.rss',3 ); 
//var_dump($my_rss);
//$x=count($my_rss);
//print "<p>x=$x</p>";

?>
<div id='col1'>

<ul class="rss-feed">
<?php foreach ($my_rss as $k => $v) : ?>
     <li>
     <span class="title"><a href="<?php echo $v['link']; ?>"  target='_blank'  ><?php echo '<b>'.$v['title'].'</b>'; ?></a></span>
     <br><span class="date"><?php echo $v['date']; ?></span>
     <br><span class="descr"><?php echo $v['descr']; ?></span>
     </li>
<?php endforeach; ?>
</ul>
</div>



</body>
</html>