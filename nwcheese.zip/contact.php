<?php
 if(!$_SERVER['HTTP_HOST'] =='localhost') {
	include ('mqttLog.php');
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
<script>
// Simulate an HTTP redirect:
window.location.replace("http://nwcheese.com/contact1.php");
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link  type="text/css" rel="stylesheet" href='cheese1.css'>
<meta name="description" content="Artisan cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest,Farmstead,artisan, Washington,Oregon">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" >

<title>NW Cheese</title>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js" ></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js" ></script>

<script type="text/javascript">

$(document).ready(function(){
	
	
	});	//end ready function
</script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-273964-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>
<div id='page'>
<div id='banner'>
</div><!-- end of banner div -->

<!--navbar -->
<?php include 'navbar.php'; ?>

<div class='intro'><h2>Contact Us</h2><br>
<!-- news items -->
<div id='news' style="width:45%;height:300px;float:left;padding:20px;">

<h3>Email: <a href='mailto:bsmith@primebiz.com?subject=nwcheese.com' >Editor</a></h3>
<h3><b>US Mail:</b></h3>
<p>NWCheese.com<br>
%Primebiz.Net
<br>PMB #87<br>
3110 Judson Street<br>
Gig Harbor, WA 98335</p>
</div>
<div style='float:right;width:45%;'>
<h3>Recipes</h3>
<p><a href='Beechers_Fondue_Recipe.pdf' target='_blank' style='color:#888888;'>Pacific Northwest Cheese Fondue</a></p>
<p><a href='http://www.thenibble.com/reviews/main/cheese/cheese2/macaroni-and-cheese-recipes5.asp' target='_blank' style='color:#888888;'>Pacific Northwest Mac & Cheese</a></p>
<h3>Links</h3>
<p><a href='https://oregoncheeseguild.org/' style='color:#888888;' target='_blank'>Oregon Cheese Guild</a></p>
<p><a href='http://www.washingtoncheese.org/' style='color:#888888;' target='_blank'>Washington State Cheesemakers Association</a></p>
<p><a href='https://www.cheesesociety.org/' style='color:#888888;'  target='_blank'>American Cheese Society</a></p>


</div>
<div id='ads'>
<script type="text/javascript"><!--
google_ad_client = "pub-9028303977713070";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-08-10: nwcheese
google_ad_channel = "1949571433";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div><!-- end of ads div -->

<div id='footer'>
<p>&copy;Copyright 2020<a href='http://primebiz.net' target='_blank'>Primebiz.Net</a></p>
</div><!-- end of footer div -->

  </div><!-- end of page div -->
<script type="text/javascript" src="navbar.js" ></script>

</body>
</html>
