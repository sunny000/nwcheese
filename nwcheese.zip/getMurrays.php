<?php
$output = shell_exec('curl https://blog.murrayscheese.com/feed/ > murrays.rss');
echo "<pre>$output</pre>";
?>