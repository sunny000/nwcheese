<?php
$version = curl_version();

$url = "https://blog.murrayscheese.com/feed/";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_VERBOSE, true);

$headers = array(
   "Origin: http://nwcheese.com",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
var_dump($resp);
print "<hr>";
var_dump($version);
print "<hr>";

foreach($version as $key => $val) {
  echo "$key = $val<br>";
}
print "<hr>";

$info=curl_getinfo($curl);
foreach($info as $key => $val) {
  echo "$key = $val<br>";
}
print "<hr>";

$error=curl_error($curl);
print $error;
?>

