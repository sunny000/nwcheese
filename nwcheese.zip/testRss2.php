<?php
require_once 'rss2Function.php';
//Runs function with feed url and number of posts as arguments
//$my_rss = fetch_rss_feed('http://cappelendesign.no/blog/feed', 5); 
$my_rss = fetch_rss_feed('http://nreionline.com/rss.xml', 5); 

?>

<ul class="rss-feed">
<?php foreach ($my_rss as $k => $v) : ?>
     <li>
     <span class="title"><a href="<?php echo $v['link']; ?>"  ><?php echo $v['title']; ?></a></span>
     <br><span class="date"><?php echo $v['date']; ?></span>
     <br><span class="descr"><?php echo $v['descr']; ?></span>
     </li>
<?php endforeach; ?>
</ul>
