<?php
 if(!($_SERVER['HTTP_HOST'] =='localhost')) {
	include ('mqttLog.php');
} ?>
<!DOCTYPE html>
<html lang="en">
<meta name=viewport content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<meta name="description" content="Artisan cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest,Farmstead,artisan, Washington,Oregon">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" >

<title>NW Cheese</title>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js" ></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js" ></script>

<script type="text/javascript">

$(document).ready(function(){
	
	
	});	//end ready function
</script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-273964-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>
<div class='container'>
	<div class="row">
		<div class='col-sm-6'>
			<img src='../images/cheese2.png' height='200px'/>
		</div>
		<div class='col-sm-6'>
			<br><h1>NW Cheesemakers</h1>
			<h4>Washington and Oregon Artisans</h4>
		</div>

	</div>
</div>
<br>

<div class='container bg-light'>
<!--navbar -->
<?php include 'navbarBS4.php'; ?>
</div>

<div class='container'><h2>Blogs</h2><br></div>

<div class='container'>
<div class="row">
    <div class="col-sm-6"><h3>Murray's</h3></div>
	<div class="col-sm-6"><h3>Cheese Culture</h3></div>
<div class="row">
    <div class="col-sm-6">
<?php include 'murrays.php'; ?>
		</div>

<div class="col-sm-6">
<?php include 'rss/cheeseCulture.php'; ?>
</div>
	</div>
</div>


<?php include 'footer.php';  ?>
</body>
</html>
