<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
	<title>MyTwit</title>
	<style type="text/css">
		ul.twitbox {
			width: 600px;
			list-style: none;
			margin: 0;
			padding: 0;
		}
		ul.twitbox li{
			border-bottom:1px dashed #D2DADA;
			padding: 10px;
			font-size: 14px;
			font-family: 'Lucida Grande',sans-serif;
			color: #333333;
		}
		ul.twitbox li.mytwitHead {
			height: 60px;
			background: url('http://www.vincentabry.com/wp-content/uploads/2008/11/twitter/follow-me-120.png') no-repeat center right;
		}
		ul.twitbox li.mytwitHead a {
			font-size: 22px;
			font-weight: bold;
		}
		ul.twitbox li.mytwitHead img{
			float: left;
			padding-right: 10px;
		}
		ul.twitbox li a {
			color: #0084B4;
			text-decoration: none;
		}
		ul.twitbox li a:hover { text-decoration: underline; }
		ul.twitbox span.twhen {
			color: #999999;
			font-family: georgia;
			font-size: 10px;
			font-style: italic;
			padding-top: 5px;
		}
	</style>
</head>
<body>
<?php
if(isset($_REQUEST['acct'])){$acct=$_REQUEST['acct'];}
else {
print "<p><b>Please include account name in request.</b><br>(format: index.php?acct={acct name})</p>";
exit;
}
if(!(include('mytwit.inc.php'))) {exit ('missing mytwit.inc.php');}
unlink('c:\\xampp\\htdocs\\twitter\\mytwit\\tmp/cache.txt');
$twitter = new myTwit();
$twitter->cacheFile = 'tmp/cache.txt'; // Read/write a local cache
$twitter->user = $acct;
$twitter->postLimit = 10;
$twitter->initMyTwit();
print $twitter->myTwitData;
?>
</body>
</html>