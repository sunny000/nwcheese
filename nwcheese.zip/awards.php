<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link  type="text/css" rel="stylesheet" href='cheese1.css'>
<style>
.heading {font-style:italic;}
.col60 {float:left;width:60%;overflow:scroll;height:500px;padding:2px;}
</style>
<meta name="description" content="Artisanal cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" />

<title>NW Cheese|Awards</title>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js" ></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js" ></script>
<script type="text/javascript">

$(document).ready(function(){
$('#wa').click(function(event) {
	window.location='wa.htm';	
	});
$('#ore').click(function(event) {
	window.location='or.htm';	
	});
$('#dir').click(function(event) {
	window.location='directory.php';	
	});	
	});	//end ready function
</script>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-273964-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</head>

<body>
<div id='page'>

<div id='banner'>
</div><!-- end of banner div -->

<!--navbar -->
<div id='navbar'>
	<button id='wa'>Washington</button> 
	<button id='ore'>Oregon</button> 
	<button id='dir'>Directory</button>
</div>

<h3>&nbsp;&nbsp;Awards - - American Cheese Society, 2013 Results</h3>
<div id='col1'>

<p>The American Cheese Society (ACS) is a not-for-profit
trade organization founded in 1983 to support the North
American artisan and specialty cheese industry. ACS provides
advocacy, education, business development, and networking
opportunities for members of the cheese industry, while
striving to continually raise the quality and availability of
cheese in North America.</p>


</div>
<div class='col60'>
<p><b>Pacific Northwest Winners!</b></p>

<p><br>2013 ACS JUDGING & COMPETITION RESULTS</b>
<br>Madison, Wisconsin
<br>August 2, 2013</p>
<p class='heading'>CAMEMBERT - MADE FROM COW’S MILK</p>
<ul>
<li>1st Agropur Fine Cheeses, QC
<br>Camembert l’Extra</li>
<li>2nd Agropur Fine Cheeses, QC
<br>Camembert Vaudreuil</li>
<li><b>3rd Kurtwood Farms, WA
<br>Dinah’s Cheese</b></li>
</ul>
</p>
<p class='heading'>OPEN CATEGORY - SOFT-RIPENED CHEESES -MADE FROM SHEEP’S OR MIXED MILKS</p>
<ul>
<li><b>1st Ancient Heritage Dairy, OR
<br>Valentine</b></li>
<li>2nd Baetje Farms LLC, MO
<br>Coeur du Clos</li>
<li>3rd Idyll Farms llc, MI
<br>Rind aged chevrotin</li></ul>
<p class='heading'>AMERICAN ORIGINALS ORIGINAL RECIPE / OPEN CATEGORY -
MADE FROM SHEEP’S MILK OR MIXED MILKS</p>
<ul>
<li>1st Central Coast Creamery, CA
<br>Seascape</li>
<li><b>2nd Beecher’s Handmade Cheese, WA
<br>Flagsheep</b></li>
<li>3rd La Moutonniere Inc., QC
<br>Sein D’Helene</li>
</ul>
<p class='heading'>OPEN CATEGORY - AMERICAN MADE/INTERNATIONAL STYLE -
MADE FROM SHEEP’S MILK OR MIXED MILKS</p><ul>
<li>1st No Award Given</li>
<li><b>2nd Ancient Heritage Dairy, OR
<br>Hannah</b></li>
<li>3rd Carr Valley Cheese Co., Inc., WI
<br>Cave Aged Mellage</li>
</ul>
<p class='heading'>MATURE CHEDDAR - AGED OVER 24 AND UP TO 48
MONTHS - ALL MILKS</p><ul>
<li><b>1st Tillamook County Creamery Association, OR
<br>Tillamook Vintage White Extra Sharp 3 Year
Reserve Cheddar</b></li>
<li>2nd Shelburne Farms, VT
<br>Farmhouse 2 Year Cheddar Extra Sharp</li>
<li>3rd The Artisan Cheese Exchange, WI
<br>Deer Creek Reserve</li>
</ul>
<p class='heading'>RINDLESS BLUE-VEINED - MADE FROM SHEEP’S MILK OR
MIXED MILKS</p><ul>
<li>1st Old Chatham Sheepherding Company, NY
<br>Ewe’s Blue</li>
<li>2nd Hook’s Cheese Company, Inc., WI
<br>EWE CALF to be KIDding Blue</li>
<li><b>3rd Rogue Creamery, OR
<br>Echo Mountain Blue</b></li>
<li>3rd Shepherd’s Way Farms, MN
<br>Big Woods Blue </li>
</ul>
<p class='heading'>BLUE-VEINED WITH A RIND OR EXTERNAL COATING -
MADE FROM COW’S MILK</p><ul>
<li><b>1st Rogue Creamery, OR
<br>Rogue River Blue
<li>2nd Rogue Creamery, OR
<br>Caveman Blue</b></li>
<li>3rd Point Reyes Farmstead Cheese Co., CA
<br>Point Reyes Bay Blue</li>
</ul>
<p class='heading'>HISPANIC & PORTUGUESE STYLE - FRESH UNRIPENED -
ALL MILKS</p><ul>
<li>1st Nuestro Queso, LLC, IL
<br>Fresco</li>
<li><b>2nd Ochoa’s Queseria, OR
<br>Don Froylan Queso Fresco</b></li>
<li>3rd Karoun Dairies Inc, CA
<br>Queso Del Valle Queso Fresco</li>
</ul>
<p class='heading'>FETA - MADE FROM GOAT’S MILK</p><ul>
<li>1st Pure Luck Farm and Dairy, TX
<br>Feta</li>
<li><b>2nd Quail Run Creamery, OR
<br>Little Goat Feta</b></li>
<li>3rd Three Graces Dairy, LLC, NC
<br>Goat Feta</li>
</ul>
<p class='heading'>FRESH UNRIPENED CHEESE WITH FLAVOR ADDED - ALL MILKS</p><ul>
<li><b>1st Face Rock Creamery, OR
<br>Vampire Slayer Curds</b></li>
<li>2nd Clock Shadow Creamery, WI
<br>Cheddar Curd with Cajun Spice</li>
<li>2nd Rising Sun Farms, UT
<br>Mild Curry Cheese Torta</li>
<li>3rd La Maison Alexis de Portneuf Inc, QC
<br>Chèvre des Neiges Fig and Orange</li>
</ul>
<p class='heading'>FARMSTEAD CHEESE WITH FLAVOR ADDED (MUST CONFORM
TO ALL GUIDELINES IN CATEGORY M) - ALL MILKS</p><ul>
<li>1st Ruggles Hill Creamery, MA
<br>Claire’s Mandell Hill</li>
<li><b>2nd Willamette Valley Cheese, OR
<br>Cumin Gouda</b></li>
<li>3rd Coach Farm, NY
<br>Coach Farm Aged Green Peppercorn Brick</li>
</ul>
<p class='heading'>HISPANIC-STYLE WITH FLAVOR ADDED - ALL MILKS</p><ul>
<li><b>1st Ochoa’s Queseria, OR
<br>Don Froylan Queso Botanero Cilantro & Jalapeno</b></li>
<li>2nd Heber Valley Artisan Cheese, UT
<br>Queso Fresco Verde</li>
<li>3rd Nuestro Queso, LLC, IL
<br>Enchilado</li>
</ul>
<p class='heading'>MONTEREY JACK WITH FLAVOR ADDED - ALL MILKS</p><ul>
<li>1st Heber Valley Artisan Cheese, UT
<br>Wasatch Back Jack</li>
<li><b>2nd Cherry Valley Dairy, WA
<br>Carrot-Nasturtium Reserve</b></li>
<li>2nd Haystack Mountain Goat Dairy, CO
<br>Haystack Mountain Green Chile Jack</li>
<li>2nd Saputo Specialty Cheese, WI
<br>Great Midwest Three Alarm Jack</li>
<li>3rd Carr Valley Cheese Co., Inc., WI
<br>Hot Pepper Jack</li>
<li>3rd Meister Cheese Company, WI
<br>Morel</li>
</ul>
<p class='heading'>OPEN CATEGORY - SMOKED CHEESES - MADE FROM
COW’S MILK</p><ul>
<li>1st Fair Oaks Farms, WI
<br>Smoked Sweet Swiss</li>
<li><b>2nd Rogue Creamery, OR
<br>Smokey Blue</b></li>
<li>3rd Fair Oaks Farms, WI
<br>Smoked Gouda</li>
</ul>
<p class='heading'>FRESH RINDLESS GOAT’S MILK CHEESE AGED 0 TO 30 DAYS
(BLACK ASH COATING PERMITTED)</p><ul>
<li>1st Cypress Grove Chevre, CA
<br>Ms. Natural</li>
<li>2nd Westfield Farm, MA
<br>Plain Capri</li>
<li><b>3rd Briar Rose Creamery, OR
<br>Classic Chevre</b></li>
<li>3rd Finica Food Specialties, ON
<br>Celebrity International Goat Cheese Original</li>
<li>3rd Goat Lady Dairy, NC
<br>Plain Spreadable Goat Cheese</li>
</ul>
<p class='heading'>GOAT’S MILK CHEESE AGED 31 TO 60 DAYS</p><ul>
<li>1st No Award Given</li>
<li><b>2nd Rivers Edge Chevre LLC, OR
<br>Rivers Edge Chevre Beltane</b></li>
<li>3rd Avalanche Cheese Company, CO
<br>Avalanche Cheese Company Lamborn Bloomer</li>
<li>3rd Montchevre-Betin, Inc., WI
<br>Mini Bucheron</li>
</ul>
<p class='heading'>OPEN CATEGORY - CHEESES MARINATED IN LIQUIDS AND
INGREDIENTS - MADE FROM COW’S MILK</p><ul>
<li>1st Lactalis American Group, CA
<br>Mozzarella Fresca marinated medallion
<li><b>2nd Beecher’s Handmade Cheese, WA
<br>Yule Kase</b></li>
<li>2nd Lactalis American Group, CA
<br>Galbani 1/3oz marinated ball</li>
<li>3rd Sartori Company, WI
<br>Sartori Limited Edition Cannella BellaVitano</li>
</ul>

</div>
<div id='ads'>
<!-- remove comment when putting new page into production
this section is commented to eliminate calls to adsense during development.
<script type="text/javascript"><!--
google_ad_client = "pub-9028303977713070";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-08-10: nwcheese
google_ad_channel = "1949571433";
//-->
<hr>

<!-- remove comment when putting new page into production
this section is commented to eliminate calls to adsense during development.

</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
-->
</div><!-- end of ads div -->

<div id='footer'>
<p>&copy;Copyright 2014 <a href='http://primebiz.net' target='_blank'>Primebiz.Net</a></p>
</div><!-- end of footer div -->
</div><!-- end of page div -->
</body>
</html>
