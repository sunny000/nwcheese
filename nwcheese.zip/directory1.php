<?php
if(!($_SERVER['HTTP_HOST'] =='localhost')) {
	include ('mqttLog.php');
}
include 'directoryHeader.php';
include 'buildFirmsBlock.php';
include 'footer.php';


?>