<?php

//send log updates via mqtt to Digital Ocean

	date_default_timezone_set ("America/Los_Angeles" );
	
$ip=$_SERVER["REMOTE_ADDR"];
$uri=$_SERVER["REQUEST_URI"];
$origUrl=$_SERVER["HTTP_CF_CONNECTING_IP"];$visitorHost="nwcheese";
$status=http_response_code();
//publish.php
  require("phpMQTT.php");
  
	$ts=date("m/d/y h:i:s A  T");

  $host = "mqtt.primebiz.net"; //mqtt host at Digital Ocean
  
  $port = 1885;
  //$username = "gwcdjfld"; 
  //$password = "Wkv3RxFYzJUh"; 
  $message = "$ip ($visitorHost)[$status] for $uri @  ;".$ts;

  //MQTT client id to use for the device. "" will generate a client id automatically
  $mqtt = new phpMQTT($host, $port, "ClientID".rand()); 

  if ($mqtt->connect(true,NULL)) {
    $mqtt->publish("primebiz.net",$message, 0);
		$message="remoteIP=".$origUrl;
	$mqtt->publish("primebiz.net",$message, 0);

    $mqtt->close();
	  //exit("<p>message sent @ ".$ts."</p>)");

  }else{
    echo "Fail or time out<br />";
  }
  ?>