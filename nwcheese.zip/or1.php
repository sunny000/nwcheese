<?php
 if(!($_SERVER['HTTP_HOST'] =='localhost')) {
	include ('mqttLog.php');
} ?>
<!DOCTYPE html>
<html lang="en">
<meta name=viewport content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<meta name="description" content="Artisan cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,Oregon,Washington,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" >

<title>Oregon Artisan Cheesemakers</title>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js" ></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js" ></script>

<script type="text/javascript">
$(document).ready(function(){

	});	//end ready function
</script>


<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-273964-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>
<div class='container'>
	<div class="row">
		<div class='col-sm-6'>
			<img src='../images/cheese2.png' height='200px'/>
		</div>
		<div class='col-sm-6'>
			<br><h1>NW Cheesemakers</h1>
			<h4>Washington and Oregon Artisans</h4>
		</div>

	</div>
</div>
<br>
<!--navbar -->
<div class='container bg-light'>
<!--navbar -->
<?php include 'navbarBS4.php'; ?>
</div>

<div class="container">
<b>Artisan cheese makers of the Pacific Northwest</b><br>
Oregon artisan, farmstead, and
specialty cheese makers placed among the top national honors awarded during
the American Cheese Society's 2007 Annual Cheese Competition, winning a
total 22 awards. The honors represent the most awards ever won by Oregon
cheese makers in a single national competition, according to the Oregon
Cheese Guild and Oregon Dairy Products Commission.
		</div><hr>
	<div class='container'>	
	<div class="row">	
		<div class="col-sm-4">
	<div ><a href='http://www.junipergrovefarm.com/'  target="_blank"  rel='noopener'>Juniper Grove Farm</a></div>
	<div >Redmond, OR</div>

	<p>There's no better place for producing top-quality goat milk cheese than the sunny, high desert of Central Oregon.
	 The region is rich with volcanic soils and blessed with fresh air and clean water originating from the Cascade Mountain snowpack.</p>
		 </div>
		 
		 
<div class="col-sm-4">
<a href='http://www.wvcheeseco.com/'  target="_blank"  rel='noopener'> Willamette Valley Cheese Company</a>
<div class='location'>Salem, OR</div>
<p>Aged a minimum of four months, Willamette Valley Cheese Company's Gouda is complex and flavorful. 
Textures range from semi-hard to soft, encapsulated by a distinctively natural rind. It gains distinction as it ages.</p>
	</div>
	
<div class="col-sm-4">
<div class='item'><a href='http://www.briarrosecreamery.com/'  target="_blank"  rel='noopener'> Briar Rose Creamery</a></div>
<div class='location'>Dundee, OR</div>
<p>Briar Rose Creamery is a small team of cheesemakers, crafting award-winning cheeses in Dundee, Oregon. Everything is made by hand, from start to finish.
 They love making great cheese that you want to eat every day and share around the table with others.</p>
 
 </div>
 </div>
 </div>
 	<div class='container'>	
	<div class="row">	
		<div class="col-sm-4">

 <div ><a href='http://www.roguecreamery.com/'  target="_blank"  rel='noopener'> Rogue Creamery</a></div>
<div class='location'>Central Point, OR</div>
<p>An artisan cheese company, with people dedicated to sustainability and the art and tradition of making the world's finest handmade cheese.</p>
</div><!-- end of col2 div -->


<div class="col-sm-4">
 <div class='item'><a href='http://www.bygeorgefarm.com/'  target="_blank"  rel='noopener'> By George Farm</a></div>
<div class='location'>Jacksonville, OR</div>
<p>Makers of award-winning <i>Honey and Sea Salt Fromage Blanc</i>. Handmade in small batches, this fermented fresh cheese is made with milk from By George's own grass-fed Jersey cows.
 Many of the ingredients are grown right on their farm in the Rogue Valley.</p>
 	</div>

 <div class="col-sm-4">
 <div>Farmstead Cheese</div>
<div class='location'>Glossary Term</div>
Cheese made on the farm using only the milk from the
cheesemaker's own herd.
	</div>
	</div>
</div>
<?php include 'footer.php'; ?>
</body>
</html>
