<?php 
if(!$_SERVER['HTTP_HOST']=='localhost') {
include ('mqttLog.php');
}
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link  type="text/css" rel="stylesheet" href='cheese1.css'>
<meta name="description" content="Artisanal cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest,Farmstead,artisan, Washington,Oregon">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" >
<meta name="google-site-verification" content="l3tjKWqan75dnplpiKXOQUTzkJl9F4kkOJQuFFXYZEk" />
<script type="text/javascript" src="https://code.jquery.com/jquery-latest.min.js" ></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js" ></script>

<title>Artisan Cheesemakers of the Pacific Northwest</title>
</head>
<body>
<div id='page'>
<div id='banner'>
</div><!-- end of banner div -->
<div id='navbar'><?php include 'navbar.php'; ?></div>
<div class='intro'><p>From the Skagit Valley to downtown Seattle, Washington cheesemakers are demonstrating their commitment to all-natural artisan products, creating cheeses that are not just popular
 in the state of Washington but that have been recognized worldwide.</p></div>


<div id='col1' style='width:400px;height:300px;float:left;' >
<div class='item' style='float:left;'><a href='http://urbancheesecraft.com/' target='_blank'>Urban Cheesecraft</a></div>
<div class='location'>Portland, Or</div>

	<iframe src="http://player.vimeo.com/video/26600153?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" width="400" height="225" frameborder="0" ></iframe>
</div>
<div style='float:left;width:350px;height:300px; padding:10px;'>
	<center>------</center>
	With kits of citric acid and rennet tablets, Claudia Lucero of UrbanCheesecraft.etsy.com proves cheese-making can be simple, local, and accessible to all.
	<p>"In less than an hour you can enjoy fresh mozzarella, ricotta, queso blanco, goat cheese and more-  made in your very own kitchen, using the milk of your choice. Try it and you won’t believe you didn’t do it sooner." </p>
	<p>Claudia</p>
		<br><a href='http://www.etsy.com/shop/urbancheesecraft' target='_blank' class='item'>Shop on-line at Urban Cheesecraft</a>

</div>
<div id='ads'>
<script type="text/javascript"><!--
google_ad_client = "pub-9028303977713070";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-08-10: nwcheese
google_ad_channel = "1949571433";
//-->
</script>

<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>


</div><!-- end of ads div -->

<div id='footer' class='clear'>
<p>&copy;Copyright 2012 <a href='http://primebiz.net' target='_blank'>Primebiz.Net</a></p>

</div><!-- end of footer div -->
</div><!-- end of page div -->
<script type="text/javascript" src="navbar.js" ></script>

</body>
</html>