<!--navbar -->
<div id='navbar'>
	<button id='wa'>Washington</button> 
	<button id='ore'>Oregon</button>  
	<button id='dir'>Directory</button>
	<button id='contact'>Contact Us</button>
</div>
