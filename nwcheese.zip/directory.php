<?php include ('mqttLog.php'); ?>
<!DOCTYPE html>
<html lang="en">
<html>
<head>
<script>
// Simulate an HTTP redirect:
window.location.replace("http://nwcheese.com/directory1.php");
</script>

<meta name=viewport content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link  type="text/css" rel="stylesheet" href='cheese1.css'>
<meta name="description" content="Artisan cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,Portland,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest,cheesemakers,bleu">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" />

<title>NW Cheese | Directory</title>
<style>
a {color:#444;text-decoration:none;}
.page {width:800px;margin:auto;border: 1px solid blue;padding:20px;}
.col1 {width:250px;float:left;}
.col2 {width:200px;float:left;}
.col3 {width:100px;float:left;}
.idcol {width:50px;float:left;}
.clear {clear:both;}
</style>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js" ></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js" ></script>


<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-273964-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</head>
<body>
<div class='page'>
<h2>Directory of Northwest Artisan Cheesemakers</h2>
<div id='banner'>
</div><!-- end of banner div -->
<!--navbar -->
<?php include 'navbar.php'; ?>

<h4>05/24/16</h4><div class='col1'> <b>Name/Website</b></div><div class='col2'><b>City, State</b></div><div class='col3'><b>Facebook</b></div><div class='col3'><b>Twitter</b></div><div class='col3'><b>Awards</b></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://207.55.114.76/goats/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Alsea Acre Goat Cheese</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Alsea</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='https://www.facebook.com/pages/Alsea-Acre-Goat-Cheese/185002258203047?sk=wall'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.ancientheritagedairy.com'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Ancient Heritage Dairy </span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Madras</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='https://www.facebook.com/AncientHeritageDairy'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'><a href='https://twitter.com/ancientheritage'  target="_blank"  rel='noopener'><img src='../images/twitter.png' /></a></div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.thecheesefarm.net/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Appel Farms</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'> Ferndale</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/pages/Appel-Farms-Cheese/88151591859'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.beecherscheese.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Beecher ’s Handmade Cheese</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Seattle</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='http://www.facebook.com/beecherscheese'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'><a href='https://twitter.com/BeechersSeattle'  target="_blank"  rel='noopener'><img src='../images/twitter.png' /></a></div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.blacksheepcreamery.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Black Sheep Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Adna</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.briarrosecreamery.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Briar Rose Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Dundee</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='http://www.facebook.com/briarrosecreamery'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'><a href='https://twitter.com/BriarRoseCheese'  target="_blank"  rel='noopener'><img src='../images/twitter.png' /></a></div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a title='No website.' <span itemprop='name'>Cada Dia Cheese</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Prineville</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.cascadiacreamery.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Cascadia Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Trout Lake</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='www.chattaroycheese.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Chattaroy Cheese Company</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Chattaroy</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/pages/Chattaroy-Cheese-Company/202236443123296'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.cherryvalleydairy.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Cherry Valley Dairy</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Duvall</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/CherryValleyDairy'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.deecreekfarm.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Dee Creek Farm</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Woodland</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='http://www.facebook.com/pages/Dee-Creek-Farm/2530341730'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.facerockcreamery.com'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Face Rock Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Bandon</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='https://www.facebook.com/facerockcreamery'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'><a href='https://twitter.com/facerockcheese'  target="_blank"  rel='noopener'><img src='../images/twitter.png' /></a></div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.fairviewfarmdairy.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Fairview Farm</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Dallas</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://fernsedgedairy.com'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Ferns Edge Goat Dairy</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Lowell</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.fragafarm.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Fraga Farm</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Sweet Home</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.glendaleshepherd.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Glendale Shepherd</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Clinton</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/glendaleshepherd'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.goldenglencreamery.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Golden Glen Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Bow</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/pages/Golden-Glen-Creamery/311294668885771'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.goldinartisangoatcheese.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Goldin Artisan Goat Cheese</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Molalla</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.gothbergfarms.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Gothberg Farms</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Bow</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='http://facebook.com/gothbergfarms'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'><a href='https://twitter.com/gothbergfarms'  target="_blank"  rel='noopener'><img src='../images/twitter.png' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.jacobscreamery.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Jacobs Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Chehalis</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/jacobscreamery'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.junipergrovefarm.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Juniper Grove Farm </span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Redmond</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.kurtwoodfarms.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Kurtwood Farms</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Vashon</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='http://www.facebook.com/kurt.timmermeister'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a title='No website.' <span itemprop='name'>La Mariposa Cheese</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Albany</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='https://www.facebook.com/pages/La-Mariposa-Cheese/114852168544186'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a title='No website.' <span itemprop='name'>Mama Terra Micro Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Williams</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='https://www.facebook.com/pages/Mama-Terra-Micro-Creamery/101349866598817'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a title='No website.' <span itemprop='name'>Meyers Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Orcas</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/MyersCreamery'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.monteilletcheese.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Monteillet Fromagerie</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Dayton</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/pages/Monteillet-Fromagerie/121736414492'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='795 Stewart Rd.'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Oak Leaf Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Grants Pass</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.ochoasqueseria.com'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Ochoa's Queseria</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Albany</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.pholiafarm.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Pholia Farm</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Rogue River</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='http://www.facebook.com/pages/Pholia-Farm/1085863424951'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.pinestumpfarms.com'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Pine Stump Farms</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Omak</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/PineStumpFarms'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://portlandcreamery.com'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Portland Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Portland</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='https://www.facebook.com/pages/Portland-Creamery/131941'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'><a href='https://twitter.com/PDXcreamery'  target="_blank"  rel='noopener'><img src='../images/twitter.png' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.quailruncreamery.com'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Quail Run Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Gaston</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='https://www.facebook.com/pages/Quail-Run-CreameryQuail-Run-Hollow/176473622387572'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.rivervalleycheese.com/index.html'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>River Valley Ranch </span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Fall City</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.roguecreamery.com'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Rogue Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Central Point</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='https://www.facebook.com/RogueCreamery'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'><a href='https://twitter.com/ROGUE_CREAMERY'  target="_blank"  rel='noopener'><img src='../images/twitter.png' /></a></div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.samishbaycheese.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Samish Bay Cheese</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Bow</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://twitter.com/samishfarmstead'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.silverspringscreamery.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Silver Springs Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Lynden</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='http://www.facebook.com/pages/Silver-Springs-Creamery/2'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.skcreamery.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Skamokawa Farmstead Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Skamokawa</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'>&nbsp;</div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.littlebrownfarm.com '  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>The Little Brown Farm</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Freeland</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='http://facebook.com/littlebrownfarm'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'><a href='https://twitter.com/LittleBrownFarm'  target="_blank"  rel='noopener'><img src='../images/twitter.png' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://threeringfarm.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Three Ring Farm</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Logsden</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='https://www.facebook.com/riversedge.chevre'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://tietonfarmandcreamery.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Tieton Farm and Creamery</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Tieton</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/TietonFarmAndCreamery'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.tumalofarms.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Tumalo Farms</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Bend</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='http://www.facebook.com/pages/Tumalo-Farms/180849051937'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'>&nbsp;</div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://www.wvcheeseco.com'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Willamette Valley Cheese</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Salem</span>, <span itemprop='addressRegion'>OR</span></div><div class='col3'><a href='https://www.facebook.com/pages/Willamette-Valley-Cheese/146925235346365'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'><a href='http://twitter.com/#!/WillametteCheez'  target="_blank"  rel='noopener'><img src='../images/twitter.png' /></a></div><div class='col3'><a href='awards.php'  target="_blank"  rel='noopener'><img src='images/star.gif' /></a></div><div class='clear'></div>
<hr><div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='http://willapahillscheese.com/'  target="_blank"  rel='noopener' title='Go To Website.'><span itemprop='name'>Willapa Hills Cheese</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>Doty</span>, <span itemprop='addressRegion'>WA</span></div><div class='col3'><a href='https://www.facebook.com/willapahillscheese'  target="_blank"  rel='noopener'><img src='../images/facebook-icon.png' /></a></div><div class='col3'><a href='https://twitter.com/willapahills'  target="_blank"  rel='noopener'><img src='../images/twitter.png' /></a></div><div class='clear'></div>
<div id='ads'>

<script type="text/javascript"><!--
google_ad_client = "pub-9028303977713070";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-08-10: nwcheese
google_ad_channel = "1949571433";
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
-->
</div><!-- end of ads div -->

<div id='footer'>
<center>
<p>&copy;Copyright 2012-2016 <a href='http://primebiz.net'  target="_blank"  rel='noopener'>Primebiz.Net</a></p>
</center>
</div><!-- end of footer div -->

</div><!-- end of page div -->
<script type="text/javascript" src="navbar.js" ></script>

</body>
</html>