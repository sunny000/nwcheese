
$('#wa').click(function(event) {
	window.location='wa.php';	
	});
$('#ore').click(function(event) {
	window.location='or.php';	
	});
$('#dir').click(function(event) {
	window.location='directory.php';	
	});	
$('#contact').click(function(event) {
	window.location='contact.php';	
	});	

