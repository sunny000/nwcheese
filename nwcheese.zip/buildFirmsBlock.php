<?php
$dataRow=array();
//print today's date
$today=date('m/d/y');	
print "<h4>$today</h4>";

// connect to db server and select db
include 'connectDB.php';

//execute a query
$query = "SELECT * FROM $table order by name" or die("Error in the consult.." . mysqli_error($link));

//execute the query.

$result = $link->query($query);

//display information:
printHeadings();
while($dataRow = mysqli_fetch_array($result)) {
$counter=$counter+1;
$facebook=''; //reset
$id=$dataRow["id"];
$url=$dataRow['url'];
if($url=='') {$url="#";}
$name=$dataRow['name'];
$city=$dataRow['city'];
$state=$dataRow['state'];
$facebook=$dataRow['facebook'];
$twitter=$dataRow['twitter'];
$award=$dataRow['award'];
	print "<hr>";
	if(!($url=='#')){
	print "<div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a href='$url' target='_blank' title='Go To Website.'><span itemprop='name'>$name</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>$city</span>, <span itemprop='addressRegion'>$state</span></div>";
	}else{
		print "<div itemscope itemtype= 'http://schema.org/Organization' class='col1'> <a title='No website.' <span itemprop='name'>$name</span></a></div>
	<div class='col2' itemprop='address' itemscope itemtype='http://schema.org/PostalAddress'><span itemprop='addressLocality'>$city</span>, <span itemprop='addressRegion'>$state</span></div>";
	}
	If($facebook) {
	print "<div class='col3'><a href='$facebook' target='_blank'><img src='images/facebook-icon.png' /></a></div>";
	}else{
	print "<div class='col3'>&nbsp;</div>";
	}
	If($twitter) {
	print "<div class='col3'><a href='$twitter' target='_blank'><img src='images/twitter.png' /></a></div>";
	}else{
		print "<div class='col3'>&nbsp;</div>";
	}
	If($award) {
	//print "<div class='col3'><a href='awards.php' target='_blank'><img src='images/star.gif' /></a></div>";
	}

	print "<div class='clear'></div>\n";
	}

function printHeadings() {
print "<div class='col1'> <b>Name/Website</b></div>";
print "<div class='col2'><b>City, State</b></div>";
print "<div class='col3'><b>Facebook</b></div>";
print "<div class='col3'><b>Twitter</b></div>";
//print "<div class='col3'><b>Awards</b></div>";
print "<div class='clear'></div>\n";
return;
}
?>