<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<meta name=viewport content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; ">
<link  type="text/css" rel="stylesheet" href='cheese1.css'>
<meta name="description" content="Artisan cheesemakers of the Pacific Northwest">
<meta name="keywords" content="Seattle,cheese,artisan,gouda,creamery,cheddar,gruyere,Pacific Northwest,Farmstead,artisan, Washington,Oregon">
<meta name="verify-v1" content="4XOVCzGwk7Il+RBnWc1YAd4dl/nva34Jvofp59rG7VE=" >

<title>NW Cheesemaker News</title>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js" ></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js" ></script>
<script type="text/javascript">

$(document).ready(function(){
$('#wa').click(function(event) {
	window.location='wa.htm';	
	});
$('#ore').click(function(event) {
	window.location='or.htm';	
	});
$('#dir').click(function(event) {
	window.location='directory.php';	
	});	
	});	//end ready function
</script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-273964-4']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>
<div id='page'>
<div id='banner'>
</div><!-- end of banner div -->
<!--navbar -->
<div id='navbar'><button id='wa'>Washington</button> <button id='ore'>Oregon</button>  <button id='dir'>Directory</button></div>

<!-- news items -->

<div id='news' style="height:500px;overflow:scroll;float:left;">
<div class='intro'><b>more from Cheese blogs around the net:</b><br>


<div >
<?php
include "testRss2Cheese.php";

?>

</div> </div>
</div>


<div id='ads'>
<script type="text/javascript"><!--
google_ad_client = "pub-9028303977713070";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text_image";
//2007-08-10: nwcheese
google_ad_channel = "1949571433";
//-->
</script>

<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div><!-- end of ads div -->

<div id='footer'>
<p>&copy;Copyright 2015 <a href='http://primebiz.net' target='_blank'>Primebiz.Net</a></p>
</div><!-- end of footer div -->

  </div><!-- end of page div -->

</body>
</html>
