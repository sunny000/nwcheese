<!-- A grey horizontal navbar that becomes vertical on small screens -->
<nav class="navbar navbar-expand-sm alert-warning">

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <button><a class="nav-link" href="index.php">Washington</a></button>
    </li>
    <li class="nav-item">
     <button> <a class="nav-link" href="or1.php">Oregon</a></button>
    </li>
    <li class="nav-item">
      <button><a class="nav-link" href="directory1.php">Directory</a></button>
    </li>
	<li class="nav-item">
      <button><a class="nav-link" href="contact1.php">Contact Us</a></button>
    </li>
	<li class="nav-item">
      <button><a class="nav-link" href="blog1.php">Blogs</a></button>
    </li>
	<li class="nav-item">
      <button><a class="nav-link" href="cheeseSearch.php">Search</a></button>
    </li>
  </ul>

</nav>
