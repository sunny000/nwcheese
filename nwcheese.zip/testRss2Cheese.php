<style>
.rss-feed {font-size:10pt;}
</style>

<?php
$d=0;
require_once 'rss2Function.php';
//Runs function with feed url and number of posts as arguments
//$my_rss = fetch_rss_feed('http://cappelendesign.no/blog/feed', 5); 
$my_rss = fetch_rss_feed('http://www.businessinsider.com/category/cheese.rss', 3); 

?>

<ul class="rss-feed">
<?php foreach ($my_rss as $k => $v) : ?>
     <li>
     <span class="title"><a href="<?php echo $v['link']; ?>"  ><?php echo $v['title']; ?></a></span>
     <br><span class="date"><?php echo $v['date']; ?></span>
	 
	 <?php
	 //exclude images
	 $x=strpos($v['descr'],"<img");//start of tag
	 if($x) {
		 $z=0; //reset
		 $y=strpos($v['descr'],">",$x);//end of tag
		 $z=$y-$z;
		 $d=substr_replace ( $v['descr'] , '' , $x , $z  );
		 //print "<p>*** x=$x -- y=$y ***</p>";
	 }
	 ?>
     <br><span class="descr">
	 <?php
	 if($d) {
		 echo $d;
		$d=0;//reset		 
	 }else{
		 echo $v['descr'];
	 }
		 ?></span>
     </li>
<?php endforeach; ?>
</ul>
