<?php
$user='447738_cheese';
$password='2343Bfs0';
$host='mariadb-037.wc2.phx1.stabletransit.com';
$db='447738_cheese';
$table='firms';
$counter=0;


$link = mysqli_connect($host,$user,$password,$db) or die("Error " . mysqli_error($link));
?>